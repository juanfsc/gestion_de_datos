Curso: K3521
Número de grupo: 12
Integrantes:
- Antonio, Tomás Julián - 1761468
- Derghazarian, Esteban Jorge Samuel - 1717613
- Salazar Crasto, Juan Francisco - 1722803
Email de responsable: tantonio@frba.utn.edu.ar